from setuptools import setup
setup(
  name='mymodule',
  version='1.0',
  description='My very first Python Module!',
  author='Bla',
  author_email='bla@bla.bla',
  url='blablabla.bla',
  py_modules=['mymodule']
)
